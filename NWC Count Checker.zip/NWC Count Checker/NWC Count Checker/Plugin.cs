﻿using Autodesk.Navisworks.Api.Plugins;
using NWCCounter;

namespace NWCCountChecker
{
    [Plugin("NWCModelExplorer",
            "VC",
            DisplayName = "NWC Model Explorer")]
    public class NWCModelExplorerPlugin : AddInPlugin
    {
        public override int Execute(params string[] parameters)
        {
            MainWindow window = new MainWindow();
            window.ShowDialog();

            return 0;
        }
    }
}