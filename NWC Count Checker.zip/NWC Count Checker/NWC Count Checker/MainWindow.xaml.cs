﻿using Autodesk.Navisworks.Api;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace NWCCountChecker
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            await LoadModelsAsync();
        }

        private async Task LoadModelsAsync()
        {
            tvModels.Items.Clear();

            txtStatus.Text = "Reading appended models...";
            txtProgress.Text = "0% Complete";
            txtCount.Text = "0";

            SetProgress(0, 1);

            Document doc = Autodesk.Navisworks.Api.Application.ActiveDocument;

            if (doc == null || doc.Models == null)
            {
                txtStatus.Text = "No active document found.";
                txtProgress.Text = "0% Complete";
                txtCount.Text = "0";
                SetProgress(0, 1);
                return;
            }

            int totalModels = 0;

            /*
             * Important:
             * This first loop is only for counting.
             * It does not sort, reverse, rename, or modify model order.
             */
            foreach (Model model in doc.Models)
            {
                totalModels++;
            }

            if (totalModels == 0)
            {
                txtStatus.Text = "No models found.";
                txtProgress.Text = "0% Complete";
                txtCount.Text = "0";
                SetProgress(0, 1);
                return;
            }

            int currentModel = 0;

            /*
             * Important:
             * This loop reads doc.Models directly.
             * No List sorting.
             * No OrderBy.
             * No Reverse.
             * No numbering.
             * Items are added exactly in Navisworks Object Tree order.
             */
            foreach (Model model in doc.Models)
            {
                currentModel++;

                string modelName = "Unnamed Model";

                try
                {
                    if (model.RootItem != null)
                    {
                        modelName = model.RootItem.DisplayName;
                    }
                }
                catch
                {
                    modelName = "Unnamed Model";
                }

                TreeViewItem item = new TreeViewItem
                {
                    Header = modelName
                };

                tvModels.Items.Add(item);

                SetProgress(currentModel, totalModels);

                txtCount.Text = currentModel.ToString();

                txtProgress.Text =
                    $"{((double)currentModel / totalModels * 100):0}% Complete";

                txtStatus.Text =
                    $"Loading {currentModel} of {totalModels}";

                await Dispatcher.InvokeAsync(
                    () => { },
                    DispatcherPriority.Background);
            }

            SetProgress(totalModels, totalModels);

            txtCount.Text = totalModels.ToString();
            txtProgress.Text = "100% Complete";
            txtStatus.Text = "Completed";
        }

        private void SetProgress(int current, int total)
        {
            if (total <= 0)
            {
                progressFill.Width = 0;
                return;
            }

            double percentage = (double)current / total;

            if (percentage < 0)
            {
                percentage = 0;
            }

            if (percentage > 1)
            {
                percentage = 1;
            }

            double trackWidth = progressTrack.ActualWidth;

            if (trackWidth <= 0)
            {
                progressTrack.UpdateLayout();
                trackWidth = progressTrack.ActualWidth;
            }

            progressFill.Width = trackWidth * percentage;
        }
    }
}